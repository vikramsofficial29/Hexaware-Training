package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.List;

import com.java.jdbc.dao.CrimeDao;
import com.java.jdbc.dao.CrimeDaoImpl;
import com.java.jdbc.model.Crime;

public class ShowAllOpenIncidentsMain {
public static void main(String[] args) {
	CrimeDao dao = new CrimeDaoImpl();
	
	try {
		List<Crime> OpenCrimeList = dao.ShowOpenIncidents();
		for (Crime crime : OpenCrimeList) {
			System.out.println(crime);
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
