package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.jdbc.dao.*;
import com.java.jdbc.model.Suspect;

public class SusByCrimeIdMain {

	public static void main(String[] args) {
		
		int crimeid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Crime ID : ");
		crimeid = sc.nextInt();
		SuspectDao dao = new SuspectDaoImpl();
		try {
			List<Suspect> SusByCrimeIDList = dao.ShowSuspectByCrimeid(crimeid);
			for (Suspect suspect : SusByCrimeIDList) {
				System.out.println(suspect);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
