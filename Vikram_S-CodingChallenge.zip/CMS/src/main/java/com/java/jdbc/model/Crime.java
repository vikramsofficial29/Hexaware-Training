package com.java.jdbc.model;

import java.sql.Date;

public class Crime {
	
	private int Crimeid;
	private String IncidentType;
	private String IncidentDate;
	private String location;
	private String description;
	private String status;
	public int getCrimeid() {
		return Crimeid;
	}
	public void setCrimeid(int crimeid) {
		Crimeid = crimeid;
	}
	public String getIncidentType() {
		return IncidentType;
	}
	public void setIncidentType(String incidentType) {
		IncidentType = incidentType;
	}
	public String getIncidentDate() {
		return IncidentDate;
	}
	public void setIncidentDate(String incidentDate) {
		IncidentDate = incidentDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Crime(int crimeid, String incidentType, String incidentDate, String location, String description,
			String status) {
		Crimeid = crimeid;
		IncidentType = incidentType;
		IncidentDate = incidentDate;
		this.location = location;
		this.description = description;
		this.status = status;
	}
	public Crime() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Crime [Crimeid=" + Crimeid + ", IncidentType=" + IncidentType + ", IncidentDate=" + IncidentDate
				+ ", location=" + location + ", description=" + description + ", status=" + status + "]";
	}
	

}
