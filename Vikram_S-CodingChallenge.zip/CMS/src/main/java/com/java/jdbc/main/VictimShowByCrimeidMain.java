package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.jdbc.dao.*;
import com.java.jdbc.model.Victim;

public class VictimShowByCrimeidMain {
	
	public static void main(String[] args) {
		
		int crimeid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Crime id : ");
		crimeid = sc.nextInt();
		VictimDao dao = new VictimDaoImpl();
		
		try {
			List<Victim> VictimList = dao.ShowVictimByCrimeid(crimeid);
			for (Victim victim : VictimList) {
				System.out.println(victim);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
