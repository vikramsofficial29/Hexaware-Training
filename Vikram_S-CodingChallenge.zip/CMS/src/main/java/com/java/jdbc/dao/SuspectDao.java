package com.java.jdbc.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.jdbc.model.Suspect;

public interface SuspectDao {

	String AddSuspect(Suspect suspect) throws ClassNotFoundException, SQLException;
	List<Suspect> ShowSuspectByCrimeid(int crimeid) throws ClassNotFoundException, SQLException;
	List<Suspect> ShowSusBysusId(int suspectid) throws ClassNotFoundException, SQLException;
}
