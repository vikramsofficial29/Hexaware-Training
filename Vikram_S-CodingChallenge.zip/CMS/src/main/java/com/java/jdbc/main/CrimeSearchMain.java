package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.*;
import com.java.jdbc.dao.*;
import com.java.jdbc.model.Crime;

public class CrimeSearchMain {

	public static void main(String[] args) {
		int crimeid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Crime ID : ");
		crimeid = sc.nextInt();
		CrimeDao dao = new CrimeDaoImpl();
		
		try {
			Crime crime = dao.CrimeSearch(crimeid);
			if(crime != null)
			{
				System.out.println(crime);
			}
			else
			{
				System.out.println("*** No Record ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
