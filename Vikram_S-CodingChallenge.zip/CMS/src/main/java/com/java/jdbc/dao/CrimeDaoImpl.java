package com.java.jdbc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.jdbc.model.Crime;
import com.java.jdbc.util.DBConnUtil;
import com.java.jdbc.util.DBPropertyUtil;

public class CrimeDaoImpl implements CrimeDao {
	
	Connection connection;
	PreparedStatement pst;

	@Override
	public List<Crime> crimeDao() throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from crime";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeList = new ArrayList<Crime>();
		Crime crime = null;
		
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("Crimeid"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getString("IncidentDate"));
			crime.setLocation(rs.getString("location"));
			crime.setDescription(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			crimeList.add(crime);
		}
		return crimeList;
	}

	@Override
	public Crime CrimeSearch(int crimeid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from crime where crimeid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crimeid);
		ResultSet rs = pst.executeQuery();
		Crime crime = null;
		if(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("Crimeid"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getString("IncidentDate"));
			crime.setLocation(rs.getString("location"));
			crime.setDescription(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
		}
		return crime;
	}

	@Override
	public List<Crime> SearchByIncidentType(String IncidentType) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from crime where IncidentType = ?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, IncidentType);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeListIncType = new ArrayList<Crime>();
		Crime crime = null;
		
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("Crimeid"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getString("IncidentDate"));
			crime.setLocation(rs.getString("location"));
			crime.setDescription(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			crimeListIncType.add(crime);
		}
		return crimeListIncType;
		
	}

	@Override
	public List<Crime> SearchByIncidentDate(String IncidentDate) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from crime where IncidentDate = ?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, IncidentDate);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeListIncDate = new ArrayList<Crime>();
		Crime crime = null;
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("Crimeid"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getString("IncidentDate"));
			crime.setLocation(rs.getString("location"));
			crime.setDescription(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			crimeListIncDate.add(crime);
		}
		return crimeListIncDate;
	}

	@Override
	public List<Crime> ShowOpenIncidents() throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from crime where status = ?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, "Open");
		ResultSet rs = pst.executeQuery();
		List<Crime> OpencrimeList = new ArrayList<Crime>();
		Crime crime = null;
		
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("Crimeid"));
			crime.setIncidentType(rs.getString("IncidentType"));
			crime.setIncidentDate(rs.getString("IncidentDate"));
			crime.setLocation(rs.getString("location"));
			crime.setDescription(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			OpencrimeList.add(crime);
		}
		return OpencrimeList;
	}

	@Override
	public String AddCrime(Crime crime) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Insert into crime(CrimeID,IncidentType,IncidentDate,Location,Description,Status)"+ "values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crime.getCrimeid());
		pst.setString(2, crime.getIncidentType());
		pst.setString(3, crime.getIncidentDate());
		pst.setString(4, crime.getLocation());
		pst.setString(5, crime.getDescription());
		pst.setString(6, crime.getStatus());
		pst.executeUpdate();
		return "Crime is Added!!!";
		
	}



}
