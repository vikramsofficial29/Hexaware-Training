package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.jdbc.model.Victim;
import com.java.jdbc.dao.*;

public class AddVictimMain {

	public static void main(String[] args) {
		
		Victim victim = new Victim();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Victim ID : ");
		victim.setVictimid(sc.nextInt());
		System.out.println("Enter The Crime ID : ");
		victim.setCrimeid(sc.nextInt());
		System.out.println("Enter Victim Name : ");
		victim.setName(sc.next());
		System.out.println("Enter The Victim's Age : ");
		victim.setAge(sc.nextInt());
		System.out.println("Enter Victim's Contact Info (email) : ");
		victim.setContactInfo(sc.next());
		System.out.println("Enter The Injury That the Victim had : ");
		victim.setInjuries(sc.next());
		
		VictimDao dao = new VictimDaoImpl();
		try {
			System.out.println(dao.AddVictim(victim));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
