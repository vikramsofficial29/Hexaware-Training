package com.java.jdbc.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.java.jdbc.model.Crime;

public interface CrimeDao {
	
	List<Crime> crimeDao() throws ClassNotFoundException, SQLException;
	Crime CrimeSearch(int crimeid) throws ClassNotFoundException, SQLException;
	List<Crime> SearchByIncidentType(String IncidentType) throws ClassNotFoundException, SQLException;
	List<Crime> SearchByIncidentDate(String IncidentDate) throws ClassNotFoundException, SQLException;
	List<Crime> ShowOpenIncidents() throws ClassNotFoundException, SQLException;
	String AddCrime(Crime crime) throws ClassNotFoundException, SQLException;

}
