package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.jdbc.model.Suspect;
import com.java.jdbc.dao.*;

public class AddSuspectMain {
	
	public static void main(String[] args) {
		
		Suspect suspect = new Suspect();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Suspect ID : ");
		suspect.setSuspectid(sc.nextInt());
		System.out.println("Enter The Crime ID : ");
		suspect.setCrimeid(sc.nextInt());
		System.out.println("Enter The Name : ");
		suspect.setName(sc.next());
		System.out.println("Enter The Age : ");
		suspect.setAge(sc.nextInt());
		System.out.println("Enter The Description : ");
		suspect.setDescription(sc.next());
		System.out.println("Enter The Criminal History : ");
		suspect.setCriminalHistory(sc.nextLine());
		
		SuspectDao dao = new SuspectDaoImpl();
		
		try {
			System.out.println(dao.AddSuspect(suspect));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
