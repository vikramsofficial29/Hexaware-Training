package com.java.jdbc.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.java.jdbc.dao.*;
import com.java.jdbc.model.Crime;

public class SearchByIncDateMain {
	
	public static void main(String[] args) throws ParseException {
		
		String IncDate;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Date (yyyy-mm-dd) : ");
		IncDate = sc.next();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = sdf.parse(IncDate);
		
		CrimeDao dao = new CrimeDaoImpl();
		
		try {
			List<Crime> crimeListIncDate = dao.SearchByIncidentDate(IncDate);
			for (Crime crime : crimeListIncDate) {
				System.out.println(crime);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
