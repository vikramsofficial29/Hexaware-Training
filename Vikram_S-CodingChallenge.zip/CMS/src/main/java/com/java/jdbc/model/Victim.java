package com.java.jdbc.model;

public class Victim {
	
	private int victimid;
	private int crimeid;
	private String name;
	private int age;
	private String contactInfo;
	private String injuries;
	public int getVictimid() {
		return victimid;
	}
	public void setVictimid(int victimid) {
		this.victimid = victimid;
	}
	public int getCrimeid() {
		return crimeid;
	}
	public void setCrimeid(int crimeid) {
		this.crimeid = crimeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}
	public String getInjuries() {
		return injuries;
	}
	public void setInjuries(String injuries) {
		this.injuries = injuries;
	}
	public Victim(int victimid, int crimeid, String name, int age, String contactInfo, String injuries) {
		this.victimid = victimid;
		this.crimeid = crimeid;
		this.name = name;
		this.age = age;
		this.contactInfo = contactInfo;
		this.injuries = injuries;
	}
	public Victim() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Victim [victimid=" + victimid + ", crimeid=" + crimeid + ", name=" + name + ", age=" + age
				+ ", contactInfo=" + contactInfo + ", injuries=" + injuries + "]";
	}
	
	
}
