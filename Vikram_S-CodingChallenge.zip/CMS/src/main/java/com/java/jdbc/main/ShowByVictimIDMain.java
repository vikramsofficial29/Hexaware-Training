package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.jdbc.dao.*;
import com.java.jdbc.model.Victim;


public class ShowByVictimIDMain {

	public static void main(String[] args) {
		
		int victimid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Victim ID : ");
		victimid = sc.nextInt();
		
		VictimDao dao = new VictimDaoImpl();
		
		try {
			Victim victim = dao.ShowByVictimId(victimid);
			if(victim != null)
			{
				System.out.println(victim);
			}
			else
			{
				System.out.println("No Record");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
