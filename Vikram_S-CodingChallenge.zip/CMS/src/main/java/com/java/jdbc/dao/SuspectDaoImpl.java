package com.java.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.jdbc.model.Suspect;
import com.java.jdbc.util.DBConnUtil;
import com.java.jdbc.util.DBPropertyUtil;

public class SuspectDaoImpl implements SuspectDao {
	Connection connection;
	PreparedStatement pst;
	
	@Override
	public String AddSuspect(Suspect suspect) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Insert into suspect(suspectid,crimeid,name,age,description,criminalHistory)"
		+ "values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, suspect.getSuspectid());
		pst.setInt(2, suspect.getCrimeid());
		pst.setString(3, suspect.getName());
		pst.setInt(4, suspect.getAge());
		pst.setString(5, suspect.getDescription());
		pst.setString(6, suspect.getCriminalHistory());
		pst.executeUpdate();
		return "Suspect Is Added";
	}

	@Override
	public List<Suspect> ShowSuspectByCrimeid(int crimeid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from suspect where crimeid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crimeid);
		ResultSet rs = pst.executeQuery();
		List<Suspect> SusbyCrimeIDList = new ArrayList<Suspect>();
		Suspect sus = null;
		while(rs.next())
		{
			sus = new Suspect();
			sus.setSuspectid(rs.getInt("suspectid"));
			sus.setCrimeid(rs.getInt("crimeid"));
			sus.setName(rs.getString("name"));
			sus.setAge(rs.getInt("age"));
			sus.setDescription(rs.getString("description"));
			sus.setCriminalHistory(rs.getString("criminalHistory"));
			SusbyCrimeIDList.add(sus);
		}
		return SusbyCrimeIDList;
	
	}

	@Override
	public List<Suspect> ShowSusBysusId(int suspectid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from suspect where suspectid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, suspectid);
		ResultSet rs = pst.executeQuery();
		List<Suspect> SusbySuspectIDList = new ArrayList<Suspect>();
		Suspect sus = null;
		while(rs.next())
		{
			sus = new Suspect();
			sus.setSuspectid(rs.getInt("suspectid"));
			sus.setCrimeid(rs.getInt("crimeid"));
			sus.setName(rs.getString("name"));
			sus.setAge(rs.getInt("age"));
			sus.setDescription(rs.getString("description"));
			sus.setCriminalHistory(rs.getString("criminalHistory"));
			SusbySuspectIDList.add(sus);
		}
		return SusbySuspectIDList;
	}
	

}
