package com.java.jdbc.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.jdbc.model.Victim;

public interface VictimDao {
	
	List<Victim> ShowVictimByCrimeid(int crimeid) throws ClassNotFoundException, SQLException;
	Victim ShowByVictimId(int victimid) throws ClassNotFoundException, SQLException;
	String AddVictim(Victim victim) throws ClassNotFoundException, SQLException;
}
