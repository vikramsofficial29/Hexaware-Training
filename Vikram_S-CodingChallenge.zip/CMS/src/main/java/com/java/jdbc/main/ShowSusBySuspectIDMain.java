package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.jdbc.dao.SuspectDao;
import com.java.jdbc.dao.SuspectDaoImpl;
import com.java.jdbc.model.Suspect;

public class ShowSusBySuspectIDMain {

public static void main(String[] args) {
	int suspectid;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter The Suspect ID : ");
	suspectid = sc.nextInt();
	SuspectDao dao = new SuspectDaoImpl();
	try {
		List<Suspect> SusBySuspectIDList = dao.ShowSusBysusId(suspectid);
		for (Suspect suspect : SusBySuspectIDList) {
			System.out.println(suspect);
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
