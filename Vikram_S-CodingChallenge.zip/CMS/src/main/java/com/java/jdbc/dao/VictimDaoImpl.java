package com.java.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.jdbc.model.Crime;
import com.java.jdbc.model.Victim;
import com.java.jdbc.util.DBConnUtil;
import com.java.jdbc.util.DBPropertyUtil;

public class VictimDaoImpl implements VictimDao {

	Connection connection;
	PreparedStatement pst;
	
	@Override
	public List<Victim> ShowVictimByCrimeid(int crimeid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from victim where crimeid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crimeid);
		ResultSet rs = pst.executeQuery();
		List<Victim> VictimList = new ArrayList<Victim>();
		Victim victim = null;
		
		while(rs.next())
		{
			victim = new Victim();
			victim.setVictimid(rs.getInt("victimid"));
			victim.setCrimeid(rs.getInt("crimeid"));
			victim.setName(rs.getString("Name"));
			victim.setAge(rs.getInt("Age"));
			victim.setContactInfo(rs.getString("contactInfo"));
			victim.setInjuries(rs.getString("injuries"));
			VictimList.add(victim);
			
		}
		return VictimList;
	}

	@Override
	public Victim ShowByVictimId(int victimid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from victim where victimid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, victimid);
		ResultSet rs = pst.executeQuery();
		Victim victim = null;
		if(rs.next())
		{
			victim = new Victim();
			victim.setVictimid(rs.getInt("victimid"));
			victim.setCrimeid(rs.getInt("crimeid"));
			victim.setName(rs.getString("Name"));
			victim.setAge(rs.getInt("Age"));
			victim.setContactInfo(rs.getString("contactInfo"));
			victim.setInjuries(rs.getString("injuries"));
		}
		return victim;
	}

	@Override
	public String AddVictim(Victim victim) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Insert into victim(victimid,crimeid,name,age,contactInfo,Injuries)"+"values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, victim.getVictimid());
		pst.setInt(2, victim.getCrimeid());
		pst.setString(3,victim.getName());
		pst.setInt(4, victim.getAge());
		pst.setString(5, victim.getContactInfo());
		pst.setString(6,victim.getInjuries());
		pst.executeUpdate();
		return "*** Victim is Added ***";
	}

}
