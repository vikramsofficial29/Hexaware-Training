package com.java.jdbc.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.java.jdbc.model.Crime;
import com.java.jdbc.dao.*;

public class AddCrimeMain {

	public static void main(String[] args) throws ParseException {
		Crime crime = new Crime();
		String IncDate;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Crime ID : ");
		crime.setCrimeid(sc.nextInt());
		System.out.println("Enter Incident Type : ");
		crime.setIncidentType(sc.next());
		System.out.println("Enter Incident Date (yyyy-mm-dd) : ");
		IncDate = sc.next();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = sdf.parse(IncDate);
		crime.setIncidentDate(IncDate);
		System.out.println("Enter The Location : ");
		crime.setLocation(sc.next());
		System.out.println("Enter The Crime Description : ");
		crime.setDescription(sc.next());
		System.out.println("Enter The Status (Open/Close) : ");
		crime.setStatus(sc.next());
		
		CrimeDao dao = new CrimeDaoImpl();
		try {
			System.out.println(dao.AddCrime(crime));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
