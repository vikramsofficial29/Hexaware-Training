insert into vehicle (model, capacity, type, status, fuel_type)
values
('MrM Travels', 150.00, 'bus', 'available', 'diesel'),
('Tempo Traveller', 125, 'van', 'on trip', 'diesel'),
('Volvo', 200.00, 'bus', 'maintenance', 'diesel'),
('Volkswagen transporter', 1800.00, 'van', 'available', 'diesel'),
('Ford', 220.00, 'van', 'available', 'petrol'),
('Force traveller', 280.00, 'van', 'available', 'diesel'),
('Tata', 300.00, 'truck', 'on trip', 'diesel'),
('Volvo vnl', 350.00, 'truck', 'available', 'diesel'),
('Toyota', 300.00, 'bus', 'maintenance', 'diesel'),
('Eicher', 400.00, 'bus', 'available', 'diesel'),
('Ashok leyland', 320.00, 'bus', 'available', 'diesel'),
('Tata winger', 150.00, 'van', 'maintenance', 'diesel'),
('Suzuki carry', 125.00, 'van', 'available', 'petrol'),
('Force traveller', 280.00, 'van', 'available', 'diesel'),
('Maruti eeco', 200.00, 'van', 'on trip', 'petrol'),
('Toyota Hiace', 220.00, 'van', 'available', 'diesel'),
('Chevrolet Express', 300.00, 'van', 'available', 'petrol'),
('Mercedes-Benz Sprinter', 2500.00, 'van', 'maintenance', 'diesel'),
('Nissan NV350', 180.00, 'van', 'available', 'diesel'),
('Renault Master', 350.00, 'van', 'on trip', 'diesel'),
('Ford Transit', 320.00, 'van', 'available', 'petrol'),
('Hyundai H350', 400.00, 'van', 'available', 'diesel'),
('Iveco Daily', 350.00, 'van', 'maintenance', 'diesel'),
('Peugeot Boxer', 280.00, 'van', 'available', 'diesel'),
('Vauxhall Movano', 300.00, 'van', 'on trip', 'diesel');


insert into Route (StartDestination, EndDestination, Distance, Availability) 
values
('Kerala', 'Chennai', 649.70, 'Available'),
('Vellore', 'Salem', 229.40, 'Available'),
('Tuticorin', 'Chennai', 604.30, 'Available'),
('Chennai', 'Bangalore', 347.50, 'Not Available'),
('Madurai', 'Tirunelveli', 161.50, 'Available'),
('Chennai', 'Kochi', 690.40, 'Available'),
('Hyderabad', 'Tirupati', 559.80, 'Available'),
('Tuticorin', 'Tirunelveli', 45.10, 'Available'),
('Chennai', 'Kanchipuram', 72.10, 'Available'),
('Hyderabad', 'Chennai', 629.70, 'Not Available'),
('Coimbatore', 'Chennai', 497.80, 'Available'),
('Trichy', 'Madurai', 134.60, 'Available'),
('Chennai', 'Trichy', 332.00, 'Not Available'),
('Trichy', 'Tirunelveli', 298.40, 'Not Available'),
('Chennai', 'Pondicherry', 159.60, 'Available'),
('Bangalore', 'Mysore', 144.50, 'Available'),
('Chennai', 'Coimbatore', 506.40, 'Available'),
('Chennai', 'Hyderabad', 627.30, 'Available'),
('Mumbai', 'Pune', 148.60, 'Available'),
('Delhi', 'Jaipur', 268.00, 'Available'),
('Kolkata', 'Durgapur', 168.90, 'Available'),
('Ahmedabad', 'Surat', 262.50, 'Available'),
('Kovai', 'Tirunelveli', 363.20, 'Not Available'),
('Lucknow', 'Kanpur', 82.10, 'Available'),
('Chennai', 'Tirunelveli', 622.70, 'Not Available'),
('Trichy', 'Kovai', 218.40, 'Not Available'),
('Bengaluru', 'Chennai', 347.80, 'Available'),
('Pune', 'Nashik', 210.30, 'Available'),
('Jaipur', 'Jodhpur', 337.20, 'Available'),
('Hyderabad', 'Vijayawada', 275.40, 'Available');


INSERT INTO Trip (VehicleID, RouteID, DepartureDate, ArrivalDate, Trip_Status, Trip_type, MaxPassengers) 
VALUES
(15, 8, '2024-05-01 08:00:00', '2024-05-01 12:00:00', 'Scheduled','Passenger', 50),
(9, 23, '2024-05-02 10:30:00', '2024-05-02 15:30:00', 'In Progress','Freight' ,40),
(3, 14, '2024-05-03 09:45:00', '2024-05-03 14:45:00', 'Completed', 'Passenger' ,30),
(5, 27, '2024-05-04 11:15:00', '2024-05-04 16:15:00', 'Scheduled', 'Freight',35),
(19, 10, '2024-05-05 13:30:00', '2024-05-05 17:30:00', 'Scheduled','Passenger', 45),
(13, 19, '2024-05-06 07:45:00', '2024-05-06 11:45:00', 'In Progress', 'Passenger' ,25),
(8, 5, '2024-05-07 10:00:00', '2024-05-07 14:00:00', 'Scheduled', 'Freight',40),
(21, 18, '2024-05-08 08:30:00', '2024-05-08 12:30:00', 'Scheduled', 'Freight',30),
(6, 2, '2024-05-09 12:45:00', '2024-05-09 17:45:00', 'In Progress','Passenger', 20),
(12, 25, '2024-05-10 11:00:00', '2024-05-10 15:00:00', 'Completed', 'Freight',30),
(17, 13, '2024-05-11 09:15:00', '2024-05-11 13:15:00', 'Scheduled', 'Passenger' ,35),
(4, 9, '2024-05-12 14:30:00', '2024-05-12 18:30:00', 'Scheduled', 'Freight',25),
(10, 3, '2024-05-13 08:45:00', '2024-05-13 13:45:00', 'In Progress', 'Passenger',40),
(24, 15, '2024-05-14 11:00:00', '2024-05-14 15:00:00', 'Scheduled', 'Freight',50),
(2, 26, '2024-05-15 10:15:00', '2024-05-15 14:15:00', 'Scheduled','Freight' ,30),
(14, 12, '2024-05-16 12:30:00', '2024-05-16 16:30:00', 'Completed','Passenger' ,35),
(22, 20, '2024-05-17 08:45:00', '2024-05-17 13:45:00', 'In Progress','Freight' ,45),
(7, 7, '2024-05-18 09:00:00', '2024-05-18 13:00:00', 'Scheduled', 'Passenger',25),
(18, 24, '2024-05-19 13:15:00', '2024-05-19 17:15:00', 'Scheduled', 'Passenger' ,30),
(16, 17, '2024-05-20 10:30:00', '2024-05-20 14:30:00', 'In Progress', 'Freight',20),
(11, 1, '2024-05-21 07:45:00', '2024-05-21 11:45:00', 'Completed', 'Passenger',40),
(25, 28, '2024-05-22 12:00:00', '2024-05-22 16:00:00', 'Scheduled', 'Passenger' ,35),
(1, 16, '2024-05-23 08:15:00', '2024-05-23 12:15:00', 'Scheduled','Passenger', 50),
(20, 11, '2024-05-24 10:30:00', '2024-05-24 14:30:00', 'In Progress', 'Freight',30),
(23, 21, '2024-05-25 09:45:00', '2024-05-25 13:45:00', 'Scheduled', 'Freight',40),
(5, 4, '2024-05-26 13:00:00', '2024-05-26 17:00:00', 'Scheduled','Passenger', 25),
(3, 22, '2024-05-27 12:15:00', '2024-05-27 16:15:00', 'In Progress', 'Freight',20),
(9, 8, '2024-05-28 09:30:00', '2024-05-28 13:30:00', 'Completed','Passenger' ,35),
(15, 3, '2024-05-29 07:45:00', '2024-05-29 11:45:00', 'Scheduled', 'Freight',30),
(17, 9, '2024-05-30 11:00:00', '2024-05-30 15:00:00', 'Scheduled', 'Passenger',40),
(7, 25, '2024-05-31 10:15:00', '2024-05-31 14:15:00', 'In Progress', 'Freight',45),
(12, 10, '2024-06-01 08:30:00', '2024-06-01 12:30:00', 'Scheduled', 'Freight',25),
(19, 6, '2024-06-02 11:45:00', '2024-06-02 15:45:00', 'Scheduled', 'Passenger',30),
(11, 18, '2024-06-03 13:00:00', '2024-06-03 17:00:00', 'In Progress', 'Freight',20),
(8, 2, '2024-06-04 08:15:00', '2024-06-04 12:15:00', 'Completed', 'Passenger' , 40),
(22, 24, '2024-06-05 10:30:00', '2024-06-05 14:30:00', 'Scheduled', 'Freight',35),
(10, 12, '2024-06-06 09:45:00', '2024-06-06 13:45:00', 'Scheduled','Passenger' ,50),
(14, 1, '2024-06-07 12:00:00', '2024-06-07 16:00:00', 'In Progress', 'Freight',30),
(21, 5, '2024-06-08 10:15:00', '2024-06-08 14:15:00', 'Scheduled','Passenger' ,25),
(6, 28, '2024-06-09 08:30:00', '2024-06-09 12:30:00', 'Scheduled','Passenger' ,30),
(20, 14, '2024-06-10 11:45:00', '2024-06-10 15:45:00', 'In Progress','Passenger',40),
(4, 11, '2024-06-11 13:00:00', '2024-06-11 17:00:00', 'Scheduled', 'Freight',45),
(13, 19, '2024-06-12 08:15:00', '2024-06-12 12:15:00', 'Scheduled','Passenger' ,25),
(24, 4, '2024-06-13 10:30:00', '2024-06-13 14:30:00', 'In Progress', 'Passenger' ,30),
(16, 27, '2024-06-14 09:45:00', '2024-06-14 13:45:00', 'Scheduled', 'Passenger' ,35),
(2, 13, '2024-06-15 12:00:00', '2024-06-15 16:00:00', 'Scheduled','Passenger' ,20),
(18, 7, '2024-06-16 10:15:00', '2024-06-16 14:15:00', 'In Progress', 'Freight',40),
(25, 22, '2024-06-17 08:30:00', '2024-06-17 12:30:00', 'Scheduled', 'Passenger',50),
(1, 26, '2024-06-18 11:45:00', '2024-06-18 15:45:00', 'Scheduled','Passenger' , 30),
(23, 3, '2024-06-19 13:00:00', '2024-06-19 17:00:00', 'In Progress', 'Freight',25),
(5, 15, '2024-06-20 08:15:00', '2024-06-20 12:15:00', 'Scheduled', 'Freight',30),
(3, 9, '2024-06-21 10:30:00', '2024-06-21 14:30:00', 'Scheduled', 'Passenger',40),
(9, 25, '2024-06-22 09:45:00', '2024-06-22 13:45:00', 'In Progress','Passenger' ,45),
(15, 8, '2024-06-23 12:00:00', '2024-06-23 16:00:00', 'Scheduled','Passenger' ,25),
(17, 5, '2024-06-24 10:15:00', '2024-06-24 14:15:00', 'Scheduled', 'Passenger',30),
(7, 20, '2024-06-25 08:30:00', '2024-06-25 12:30:00', 'In Progress','Passenger' ,40),
(12, 14, '2024-06-26 11:45:00', '2024-06-26 15:45:00', 'Scheduled', 'Passenger',50),
(19, 1, '2024-06-27 13:00:00', '2024-06-27 17:00:00', 'Scheduled', 'Freight',30),
(11, 11, '2024-06-28 08:15:00', '2024-06-28 12:15:00', 'In Progress','Passenger', 25),
(8, 18, '2024-06-29 10:30:00', '2024-06-29 14:30:00', 'Scheduled','Passenger' ,30),
(22, 4, '2024-06-30 09:45:00', '2024-06-30 13:45:00', 'Scheduled', 'Passenger',40);

 -- Adding Driver Id To Trips Table
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '20' WHERE (`Trip_ID` = '1');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '1' WHERE (`Trip_ID` = '3');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '19' WHERE (`Trip_ID` = '5');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '2' WHERE (`Trip_ID` = '7');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '18' WHERE (`Trip_ID` = '9');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '3' WHERE (`Trip_ID` = '11');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '17' WHERE (`Trip_ID` = '13');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '4' WHERE (`Trip_ID` = '15');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '16' WHERE (`Trip_ID` = '17');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '5' WHERE (`Trip_ID` = '19');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '15' WHERE (`Trip_ID` = '21');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '6' WHERE (`Trip_ID` = '23');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '14' WHERE (`Trip_ID` = '25');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '7' WHERE (`Trip_ID` = '27');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '13' WHERE (`Trip_ID` = '29');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '8' WHERE (`Trip_ID` = '31');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '12' WHERE (`Trip_ID` = '33');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '9' WHERE (`Trip_ID` = '35');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '11' WHERE (`Trip_ID` = '37');
UPDATE `transportmanagementsystem`.`trip` SET `driverid` = '10' WHERE (`Trip_ID` = '40');


INSERT INTO Driver (DriverName, PhoneNo, DriverStatus, TripID, VehicleID)
VALUES
('Rajinikanth', 9876543210, 'Available', 5, 18),
('Vijay', 9876543211, 'Available', 31, 7),
('Ajith', 9876543212, 'Available', 9, 20),
('Suriya', 9876543213, 'Not Available', 25, 13),
('Vikram', 9876543214, 'Available', 56, 22),
('Dhanush', 9876543215, 'Not Available', 10, 2),
('Kamal Haasan', 9876543216, 'Available', 41, 12),
('Sivakarthikeyan', 9876543217, 'Not Available', 6, 3),
('Fahad Fasil', 9876543218, 'Available', 27, 1),
('Leo Antony', 9876543219, 'Available', 14, 25),
('Arjun Das', 9876543220, 'Available', 36, 11),
('Karthi', 9876543221, 'Not Available', 18, 17),
('Vikram Prabu', 9876543222, 'Available', 20, 8),
('Dhanish Ahmed', 9876543223, 'Available', 51, 4),
('Pavithran', 9876543224, 'Not Available', 44, 9),
('Siva', 9876543225, 'Available', 2, 15),
('Gajini', 9876543226, 'Not Available', 38, 23),
('Vijay Kumar', 9876543227, 'Not Available', 49, 16),
('Arya', 9876543228, 'Available', 33, 24),
('Rolex', 9876543229, 'Available', 11, 5);


INSERT INTO Passenger (FirstName, Gender, Age, Email, PhoneNumber) 
VALUES ('John', 'Male', 30, 'john@gmail.com', '9234567890'),
('Zoya', 'Female', 25, 'zoya@gmail.com', '9876543210'),
('Michael', 'Male', 45, 'michael@gmail.com', '9567891230'),
('Sophia', 'Female', 35, 'sophia@gmail.com', '7891234560'),
('James', 'Male', 28, 'james@gmail.com', '6216549870'),
('Olivia', 'Female', 22, 'olivia@gmail.com', '6543219870'),
('William', 'Male', 40, 'william@gmail.com', '8561237890'),
('Tara', 'Female', 31, 'tara@gmail.com', '8873216540'),
('Benjamin', 'Male', 27, 'benjamin@gmail.com', '6547891230'),
('Bela', 'Female', 33, 'bela@gmail.com', '8239874560'),
('Charlie', 'Male', 29, 'charlie@gmail.com', '9217894560'),
('Sophia', 'Female', 24, 'sophia2@gmail.com', '7894561230'),
('Alexander', 'Male', 38, 'alexander@gmail.com', '6569873210'),
('Alia', 'Female', 26, 'alia@gmail.com', '9874563210'),
('Daniel', 'Male', 32, 'daniel@gmail.com', '6219876540');

INSERT INTO Booking (Trip_ID, PassengerID, BookingDate, Status) VALUES
(5, 8, '2024-05-01 08:00:00', 'Confirmed'),
(17, 12, '2024-05-02 10:30:00', 'Confirmed'),
(23, 6, '2024-05-03 09:45:00', 'Cancelled'),
(17, 3, '2024-05-04 11:15:00', 'Completed'),
(30, 7, '2024-05-05 13:30:00', 'Confirmed'),
(45, 15, '2024-05-06 07:45:00', 'Confirmed'),
(2, 1, '2024-05-07 10:00:00', 'Cancelled'),
(8, 9, '2024-05-08 08:30:00', 'Completed'),
(13, 14, '2024-05-09 12:45:00', 'Confirmed'),
(25, 5, '2024-05-10 11:00:00', 'Cancelled'),
(40, 10, '2024-05-11 09:15:00', 'Completed'),
(52, 2, '2024-05-12 14:30:00', 'Confirmed'),
(19, 13, '2024-05-13 08:45:00', 'Cancelled'),
(36, 11, '2024-05-14 11:00:00', 'Completed'),
(11, 4, '2024-05-15 10:15:00', 'Confirmed'),
(28, 8, '2024-05-16 12:30:00', 'Cancelled'),
(9, 15, '2024-05-17 08:45:00', 'Completed'),
(7, 6, '2024-05-18 09:00:00', 'Confirmed'),
(33, 2, '2024-05-19 13:15:00', 'Cancelled'),
(15, 12, '2024-05-20 10:30:00', 'Completed'),
(47, 1, '2024-05-21 07:45:00', 'Confirmed'),
(3, 10, '2024-05-22 12:00:00', 'Cancelled'),
(45, 5, '2024-05-23 08:15:00', 'Completed'),
(39, 9, '2024-05-24 10:30:00', 'Confirmed'),
(58, 14, '2024-05-25 09:45:00', 'Cancelled'),
(14, 7, '2024-05-26 13:00:00', 'Completed'),
(29, 3, '2024-05-27 12:15:00', 'Confirmed'),
(50, 11, '2024-05-28 09:30:00', 'Cancelled'),
(20, 4, '2024-05-29 07:45:00', 'Completed'),
(43, 8, '2024-05-30 11:00:00', 'Confirmed'),
(32, 13, '2024-06-01 08:00:00', 'Confirmed'),
(49, 6, '2024-06-02 10:30:00', 'Confirmed'),
(18, 9, '2024-06-03 09:45:00', 'Cancelled'),
(27, 4, '2024-06-04 11:15:00', 'Completed'),
(41, 11, '2024-06-05 13:30:00', 'Confirmed'),
(56, 2, '2024-06-06 07:45:00', 'Confirmed'),
(18, 14, '2024-06-07 10:00:00', 'Cancelled'),
(35, 7, '2024-06-08 08:30:00', 'Completed'),
(53, 10, '2024-06-09 12:45:00', 'Confirmed'),
(9, 1, '2024-06-10 11:00:00', 'Cancelled');





