select * from vehicle;

select * from route;

select * from trip;

select * from driver;
select * from passenger;

select * from booking;




