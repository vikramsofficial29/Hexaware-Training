drop database if exists TransportManagementSystem;

create database TransportManagementSystem;

use TransportManagementSystem;

-- drop table if exists vehicles;

create table vehicle 
( 
vehicleid int auto_increment primary key, 
model varchar(255), 
capacity decimal(10, 2), 
type varchar(50), 
status varchar(50),
fuel_type varchar(50)
);

-- drop table if exists routes;

create table Route
(
RouteID int primary key auto_increment,
StartDestination varchar(255),
EndDestination varchar(255),
Distance decimal(10,2),
Availability varchar(20)
);



-- drop table trips;

create table Trip (
    Trip_ID int auto_increment primary key,
    VehicleID int,
    RouteID int,
    DepartureDate datetime,
    ArrivalDate datetime,
    Trip_Status varchar(50),
    Trip_Type varchar(50) default 'Freight',
    MaxPassengers int,
    foreign key (VehicleID) references Vehicle(VehicleID) on delete cascade,
    foreign key (RouteID) references Route(RouteID) on delete cascade
);

create table Driver(
Driverid int auto_increment primary key,
DriverName varchar(30),
phoneNo bigint,
DriverStatus varchar(30),
Tripid int,
vehicleid int,
foreign key (Tripid) references Trip(Trip_id) on delete cascade,
foreign key (vehicleid) references Vehicle(VehicleID) on delete cascade
);

-- driverid column to trips table
alter table trip
add column driverid int;



-- drop table passengers

create table Passenger(
	PassengerID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(255),
    Gender VARCHAR(255),
    Age INT,
    Email VARCHAR(255) UNIQUE,
    PhoneNumber VARCHAR(50)
);

CREATE TABLE Booking (
    BookingID INT AUTO_INCREMENT PRIMARY KEY,
    Trip_ID INT,
    PassengerID INT,
    BookingDate DATETIME,
    Status VARCHAR(50),
    FOREIGN KEY (Trip_ID) REFERENCES Trip(Trip_ID) on delete cascade,
    FOREIGN KEY (PassengerID) REFERENCES Passenger(PassengerID) on delete cascade
);




