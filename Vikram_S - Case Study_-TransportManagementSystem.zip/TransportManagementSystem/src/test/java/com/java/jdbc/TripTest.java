package com.java.jdbc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.java.jdbc.model.Trip;

public class TripTest {

	
	@Test
	public void TestConstructors()
	{
		Trip t = new Trip();
		assertNotNull(t);
		Trip t1 = new Trip(1,2,2,"2024-05-02","2024-05-08","Scheduled","Passenger", 100,4);
		
		assertEquals(1, t1.getTripid());
		assertEquals(2, t1.getRouteid());
		assertEquals(2, t1.getRouteid());
		assertEquals("2024-05-02", t1.getDepaturedate());
		assertEquals("2024-05-08",t1.getArrivaldate());
		assertEquals("Scheduled",t1.getTripStatus());
		assertEquals("Passenger", t1.getTripType());
		assertEquals(100, t1.getMaxPassengers());
		assertEquals(4, t1.getDriverid());
		
	}
	
	@Test
	public void testGetterSetter()
	{
		Trip t = new Trip();
		t.setTripid(1);
		t.setVehicleid(2);
		t.setRouteid(3);
		t.setDepaturedate("2024-05-02");
		t.setArrivaldate("2024-05-08");
		t.setTripStatus("Scheduled");
		t.setTripType("Passenger");
		t.setMaxPassengers(100);
		t.setDriverid(4);
		
		assertEquals(1, t.getTripid());
		assertEquals(2, t.getVehicleid());
		assertEquals(3, t.getRouteid());
		assertEquals("2024-05-02", t.getDepaturedate());
		assertEquals("2024-05-08",t.getArrivaldate());
		assertEquals("Scheduled",t.getTripStatus());
		assertEquals("Passenger", t.getTripType());
		assertEquals(100, t.getMaxPassengers());
		assertEquals(4, t.getDriverid());
	}
	
	@Test
	public void testHashcode()
	{
		Trip t1 = new Trip(1,2,2,"2024-05-02","2024-05-08","Scheduled","Passenger", 100,4);
		Trip t2 = new Trip(1,2,2,"2024-05-02","2024-05-08","Scheduled","Passenger", 100,4);
		assertEquals(t1.hashCode(), t2.hashCode());

	}
	
	@Test
	public void testEquals()
	{
		Trip t1 = new Trip(1,2,2,"2024-05-02","2024-05-08","Scheduled","Passenger", 100,4);
		Trip t2 = new Trip(1,2,2,"2024-05-02","2024-05-08","Scheduled","Passenger", 100,4);
		Trip t3 = new Trip(1,3,2,"2024-05-02","2024-05-08","Scheduled","Frieght", 100,6);
		assertTrue(t1.equals(t2));
		assertFalse(t1.equals(t3));

	}
	
	
	@Test
	public void testToString()
	{
		Trip t1 = new Trip(1,2,2,"2024-05-02","2024-05-08","Scheduled","Passenger", 100,4);
		String result = "Trip [tripId=1, vehicleId=2, routeId=3, departureDate=2024-05-02, arrivalDate="
				+ "2024-05-08, tripStatus=Scheduled, tripType=Passenger,maxPassengers=100,driverid=4]";
		assertEquals(t1.toString(), result);
	}

}
