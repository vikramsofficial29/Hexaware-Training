package com.java.jdbc;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.jdbc.model.Driver;

public class DriverTest {

	@Test
	public void testConstructors() {
		
		Driver d1 = new Driver();
		assertNotNull(d1);
		
		Driver d = new Driver(1,"Dilli",980980000,"Available",2,3);
		assertEquals(1, d.getDriverid());
		assertEquals("Dilli", d.getDriverName());
		assertEquals(980980000, d.getPhoneNo());
		assertEquals("Available", d.getDriverStatus());
		assertEquals(2, d.getTripid());
		assertEquals(3, d.getVehicleid());
	}

	
	@Test
	public void testGetterSetter()
	{
		Driver d = new Driver();
		d.setDriverid(1);
		d.setDriverName("Dilli");
		d.setPhoneNo(980980000);
		d.setDriverStatus("Available");
		d.setTripid(2);
		d.setVehicleid(3);
		
		assertEquals(1, d.getDriverid());
		assertEquals("Dilli", d.getDriverName());
		assertEquals(980980000, d.getPhoneNo());
		assertEquals("Available", d.getDriverStatus());
		assertEquals(2, d.getTripid());
		assertEquals(3, d.getVehicleid());
	}
	
	@Test
	public void testHashcode()
	{
		Driver d1 = new Driver(1,"Dilli",980980000,"Available",2,3);
		Driver d2 = new Driver(1,"Dilli",980980000,"Available",2,3);
		assertEquals(d1.hashCode(), d2.hashCode());
	}
	
	@Test
	public void testEquals()
	{
		Driver d1 = new Driver(1,"Dilli",980980000,"Available",2,3);
		Driver d2 = new Driver(1,"Dilli",980980000,"Available",2,3);
		Driver d3 = new Driver(1,"Rolex",980970000,"Available",4,3);

		assertTrue(d1.equals(d2));
		assertFalse(d1.equals(d3));
	}
	
	@Test
	public void testToString()
	{
		Driver d1 = new Driver(1,"Dilli",980980000,"Available",2,3);
		String res = "Driver [driverid=1, driverName=Dilli, phoneNo=980980000, driverStatus=Available"
				+ ", tripid=2, vehicleid=3]";
		assertEquals(d1.toString(), res);
	}
}
