package com.java.jdbc;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.jdbc.model.vehicle;

public class VehicleTest {


	@Test
	public void testConstructors() {
		vehicle vehi = new vehicle();
		assertNotNull(vehi);
		
		vehicle veh = new vehicle(26,"Lancer", 500.000,"car","available","petrol");
		assertEquals(26, veh.getVehicleid());
		assertEquals("Lancer", veh.getModel());
		assertEquals(500.000 , veh.getCapacity(), 0.001);
		assertEquals("car" , veh.getType());
		assertEquals("available", veh.getStatus());
		assertEquals("petrol", veh.getFuel_type());
		
	}

	
	@Test
	public void testGettersAndSetters()
	{
	vehicle v= new vehicle();
	v.setVehicleid(1);
	v.setModel("tata");
	v.setCapacity(150.00);
	v.setType("bus");
	v.setStatus("available");
	assertEquals(1,v.getVehicleid());
	assertEquals("tata",v.getModel());
	assertEquals(150.00,v.getCapacity(),0.0001);
	assertEquals("bus",v.getType());
	assertEquals("available",v.getStatus());
	
	}
	
	@Test
	public void testHashCode()
	{
		vehicle v1 = new vehicle(26,"Lancer", 500.000,"car","available","petrol");
		vehicle v2 = new vehicle(26,"Lancer", 500.000,"car","available","petrol");
		assertEquals(v1.hashCode(), v2.hashCode());
	}
	

	@Test
	public void testEquals()
	{
		vehicle v1 = new vehicle(26,"Lancer", 500.000,"car","available","petrol");
		vehicle v2 = new vehicle(26,"Lancer", 500.000,"car","available","petrol");
		vehicle v3 = new vehicle(26,"Breeza", 700.000,"truck","available","petrol");
//		assertEquals(v1, v2);
		assertTrue(v1.equals(v2));
		assertFalse(v1.equals(v3));
	}
	
	 @Test
	    public void testToString() {
		 
	       int vehicleid = 1;
	        String model = "Model X";
	        double capacity = 1000.5;
	        String type = "Truck";
	        String Status = "Available";
	        String fuel_type = "Diesel";

	        vehicle v4 = new vehicle(vehicleid, model, capacity, type, Status, fuel_type);

	        String res = v4.toString();
	        
	        String exp = "vehicle [vehicleid=" + vehicleid + ", model=" + model + ", capacity=" + capacity + ", type=" + type
					+ ", Status=" + Status + ", fuel_type=" + fuel_type + "]";
	        
	        assertEquals(exp, res);
	 
	    }
	 
	}






