package com.java.jdbc;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.java.jdbc.exceptions.BookingNotFoundException;
import com.java.jdbc.exceptions.VehicleNotFoundException;
import com.java.jdbc.model.Driver;

public class AppTest {

  @Test
  public void testMain() throws VehicleNotFoundException, BookingNotFoundException {
    TransportManagementApp.main(null);
  }

}
