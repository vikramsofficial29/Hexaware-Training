package com.java.jdbc;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.jdbc.model.Booking;

public class BookingTest {

	@Test
	public void testConstructors() {
		Booking B1 = new Booking();
		assertNotNull(B1);
		
		Booking B2 = new Booking(1,5,8,"2024-05-01 08:00:00","Confirmed");
		assertEquals(1, B2.getBookingID());
		assertEquals(5, B2.getTripid());
		assertEquals(8,B2.getPassengerid());
		assertEquals("2024-05-01 08:00:00" , B2.getBookingDate());
		assertEquals("Confirmed", B2.getStatus());
		
	}
	
	@Test
	public void testGetterSetter() {
		Booking b = new Booking();
		b.setBookingID(1);
		b.setTripid(5);
		b.setPassengerid(8);
		b.setBookingDate("2024-05-01 08:00:00");
		b.setStatus("Confirmed");
		
		assertEquals(1, b.getBookingID());
		assertEquals(5, b.getTripid());
		assertEquals(8,b.getPassengerid());
		assertEquals("2024-05-01 08:00:00" , b.getBookingDate());
		assertEquals("Confirmed", b.getStatus());
	}
	
	@Test
	public void testHashCode() {
		Booking b1 = new Booking(1,5,8,"2024-05-01 08:00:00","Confirmed");
		Booking b2 = new Booking(1,5,8,"2024-05-01 08:00:00","Confirmed");
		assertEquals(b1.hashCode(),b2.hashCode());
	}
	
	@Test
	public void testEquals() {
		Booking b1 = new Booking(1,5,8,"2024-05-01 08:00:00","Confirmed");
		Booking b2 = new Booking(1,5,8,"2024-05-01 08:00:00","Confirmed");
		Booking b3 = new Booking(1,6,7,"2024-05-03 08:00:00","Confirmed");
		assertTrue(b1.equals(b2));
		assertFalse(b2.equals(b3));
	}
	
	@Test
	public void testToString() {
		Booking b1 = new Booking(1,5,8,"2024-05-01 08:00:00","Confirmed");
		String res = "Booking [bookingID=1, tripid=5, passengerid=8, bookingDate=2024-05-01 08:00:00, Status=Confirmed]";
		assertEquals(b1.toString(),res);
		
	}

	

}
