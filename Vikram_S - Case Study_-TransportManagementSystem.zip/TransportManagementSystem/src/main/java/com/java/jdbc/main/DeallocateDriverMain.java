package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.jdbc.dao.*;

public class DeallocateDriverMain {

	public static void main(String[] args) {
		
		int tripid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Trip ID (1-60) : ");
		tripid = sc.nextInt();
		DriverDao dao = new DriverDaoImpl();
		try {
			if(dao.DeallocateDriver(tripid)) {
				System.out.println("Driver Deallocated");
			}
			else
			{
				System.out.println("No Record Found");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
