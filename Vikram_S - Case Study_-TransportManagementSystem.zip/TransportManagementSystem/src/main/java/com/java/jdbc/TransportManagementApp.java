package com.java.jdbc;

import java.util.Scanner;

import com.java.jdbc.main.VehicleDeleteMain;
import com.java.jdbc.main.VehicleInsertMain;
import com.java.jdbc.main.VehicleSearchMain;
import com.java.jdbc.main.VehicleShowMain;
import com.java.jdbc.main.VehicleUpdateMain;
import com.java.jdbc.exceptions.BookingNotFoundException;
import com.java.jdbc.exceptions.VehicleNotFoundException;
import com.java.jdbc.main.*;

public class TransportManagementApp {

	private static void DisplayChoice() {
        System.out.println("\n--- Transport Management Menu ---");
        System.out.println("1. Add Vehicle");
        System.out.println("2. Update Vehicle");
        System.out.println("3. Delete Vehicle");
        System.out.println("4. Show Vehicle");
        System.out.println("5. Search Vehicle By VehicleID");
        System.out.println("6. Schedule Trip");
        System.out.println("7. Cancel Trip");
        System.out.println("8. Book Trip");
        System.out.println("9. Cancel Booking");
        System.out.println("10. Allocate Driver");
        System.out.println("11. Deallocate Driver");
        System.out.println("12. Get Bookings By Passenger");
        System.out.println("13. Get Bookings By Trip");
        System.out.println("14. Get Available Drivers");
        System.out.println("15. Exit");
        System.out.print("Enter your choice: ");
    }
	
	private static int getUserChoice() {
		Scanner sc = new Scanner(System.in);
        return sc.nextInt();
    }
  public static void main(String[] args) throws VehicleNotFoundException, BookingNotFoundException {
	  
	  boolean end = false;
	  
	  while(!end)
	  {
		  DisplayChoice();
		  int choice = getUserChoice();
		  
		  switch(choice)
		  {
		  		case 1:
		  			System.out.println("1. Give Details For Adding Vehicle : ");
		  			VehicleInsertMain vi = new VehicleInsertMain();
		  			vi.main(args);
		  			break;
		  			
		  		case 2:
		  			System.out.println("2. Give Details Update vehicle : ");
		  			VehicleUpdateMain vehiupdate = new VehicleUpdateMain();
		  			vehiupdate.main(args);
		  			break;
		  		
		  		case 3:
		  			System.out.println("3. Give Details To Delete Vehicle : ");
		  			VehicleDeleteMain vehidel = new VehicleDeleteMain();
		  			vehidel.main(args);
		  			break;
		  		
		  		case 4:
		  			System.out.println("4. Vehicle List : ");
		  			VehicleShowMain showvehi = new VehicleShowMain();
		  			showvehi.main(args);
		  			break;
		  			
		  		case 5:
		  			System.out.println("5. Search Vehicle By VehicleID : ");
		  			VehicleSearchMain vehisearch = new VehicleSearchMain();
		  			vehisearch.main(args);
		  			break;
		  		
		  		case 6:
		  			System.out.println("6. Give Details Schedule Trip:");
		  			ScheduleTripMain schtrip = new ScheduleTripMain();
		  			schtrip.main(args);
		  			break;
		  		
		  		case 7:
		  			 System.out.println("7. Cancel Trip");
		  			 CancelTripMain cantrip = new CancelTripMain();
		  			 cantrip.main(args);
		  			 break;
		  			 
		  		case 8:
		  			 System.out.println("8. Book Trip");
		  			 AddBookingMain addbook = new AddBookingMain();
		  			 addbook.main(args);
		  			 break;
		  		
		  		case 9:
		  			 System.out.println("9. Cancel Booking");
		  			 CancelBookingMain canbook = new CancelBookingMain();
		  			 canbook.main(args);
		  			 break;
		  		
		  		case 10:
		  			System.out.println("10. Allocate Driver");
		  			AllocateDriverMain allocatedriver = new AllocateDriverMain();
		  			allocatedriver.main(args);
		  			break;
		  		
		  		case 11:
		  			 System.out.println("11. Deallocate Driver");
		  			 DeallocateDriverMain deDriver = new DeallocateDriverMain();
		  			 deDriver.main(args);
		  			 break;
		  		
		  		case 12:
		  			 System.out.println("12. Get Bookings By Passenger");
		  			 GetBookingByPidMain BookByPid = new GetBookingByPidMain();
		  			 BookByPid.main(args);
		  			 break;
		  		
		  		case 13:
		  			System.out.println("13. Get Bookings By Trip");
		  			GetBookingsByTripIdMain BookByTid = new GetBookingsByTripIdMain();
		  			BookByTid.main(args);
		  			break;
		  		
		  		case 14:
		  			 System.out.println("14. Get Available Drivers");
		  			 GetAvailableDriverMain availDriver = new GetAvailableDriverMain();
		  			 availDriver.main(args);
		  			 break;
		  		  
		  		case 15:
		  			end = true;
		  			break;
		  			
		  	  default:
                  System.out.println("Invalid choice. Please try again.");
		  }
		  
	  }
	  System.out.println("Exiting Transport Management Application...");
	  

	    
  }

  
}
