package com.java.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.jdbc.model.Driver;
import com.java.jdbc.model.Trip;
import com.java.jdbc.util.DBConnUtil;
import com.java.jdbc.util.DBPropertyUtil;

public class TripDaoImpl implements TripDao {

	Connection connection;
	PreparedStatement pst;
	
	@Override
	public boolean ScheduleTrip(Trip trip) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Insert into trip(vehicleid,routeid,arrivalDate,departureDate,trip_Status,trip_Type,maxPassengers)"+
		"values(?,?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, trip.getVehicleid());
		pst.setInt(2, trip.getRouteid());
		pst.setString(3, trip.getArrivaldate());
		pst.setString(4, trip.getDepaturedate());
		pst.setString(5, trip.getTripStatus());
		pst.setString(6, trip.getTripType());
		pst.setInt(7,trip.getMaxPassengers());
		int AffectedRows = pst.executeUpdate();
		return AffectedRows > 0;
		
		
	}
	
	
	
	@Override
	public Trip SearchTrip(int tripid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from trip where trip_id = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, tripid);
		ResultSet rs = pst.executeQuery();
		
		Trip trip = null;
		if(rs.next())
		{
			trip = new Trip();
			
			trip.setTripid(rs.getInt("trip_id"));
			trip.setVehicleid(rs.getInt("vehicleid"));
			trip.setRouteid(rs.getInt("routeid"));
			trip.setArrivaldate(rs.getString("arrivalDate"));
			trip.setDepaturedate(rs.getString("departureDate"));
			trip.setTripStatus(rs.getString("trip_status"));
			trip.setTripType(rs.getString("trip_type"));
			trip.setMaxPassengers(rs.getInt("maxPassengers"));
		}
		return trip;
	}

	@Override
	public boolean CancelTrip(int tripid) throws ClassNotFoundException, SQLException {
		
		Trip tripFound = SearchTrip(tripid);
		if(tripFound != null)
		{
			String ConnStr = DBPropertyUtil.getConnectionString("db");
			connection = DBConnUtil.getConnection(ConnStr);
			String cmd = "delete from trip where trip_id = ?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, tripid);
			int AffectedRows = pst.executeUpdate();
			return AffectedRows > 0;
		}
		return false;
		
	}


	@Override
	public boolean AllocateDriver(int tripid,int driverid) throws ClassNotFoundException, SQLException {
//		Driver driver = new Driver();
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Update Trip Set driverid = ? where trip_id = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, driverid);
		pst.setInt(2, tripid);
		int AffectedRows = pst.executeUpdate();
		return AffectedRows > 0;
	}



	
}
