package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.jdbc.dao.*;

public class CancelTripMain {

	public static void main(String[] args) {
		
		int tripid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Trip ID (1-60) : ");
		tripid = sc.nextInt();
		TripDao dao = new TripDaoImpl();
		
		try {
			if(dao.CancelTrip(tripid))
			{
				System.out.println("Trip Cancelled Successfully!!");
			}
			else
			{
				System.out.println("No Record Found");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
