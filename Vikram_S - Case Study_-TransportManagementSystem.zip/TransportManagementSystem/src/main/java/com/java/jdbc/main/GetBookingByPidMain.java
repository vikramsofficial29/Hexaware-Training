package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import com.java.jdbc.dao.*;
import com.java.jdbc.model.Booking;


public class GetBookingByPidMain {
	
	public static void main(String[] args) {
		int passengerid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Passenger ID (1-15) :");
		passengerid = sc.nextInt();
		BookingDao dao = new BookingDaoImpl();
		try {
			List<Booking> bookListByPid = dao.getBookingByPassesnger(passengerid);
			for (Booking booking : bookListByPid) {
				System.out.println(booking);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
