package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.jdbc.dao.*;

public class AllocateDriverMain {

	public static void main(String[] args) {
		int tripid,driverid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Trip ID (1-60) : ");
		tripid = sc.nextInt();
		System.out.println("Enter The Driver ID (1-20) ");
		driverid = sc.nextInt();
		TripDao dao = new TripDaoImpl();
		try {
			if(dao.AllocateDriver(tripid,driverid)) {
				System.out.println("Driver Allocated !!");
			}
			else
			{
				System.out.println("No Trip Exists");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
