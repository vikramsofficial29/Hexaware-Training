package com.java.jdbc.model;

import java.util.Objects;

public class vehicle {
	
	private int vehicleid;
	private String model;
	private double capacity;
	private String type;
	private String Status;
	private String fuel_type;
	public int getVehicleid() {
		return vehicleid;
	}
	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getCapacity() {
		return capacity;
	}
	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getFuel_type() {
		return fuel_type;
	}
	public void setFuel_type(String fuel_type) {
		this.fuel_type = fuel_type;
	}
	public vehicle(int vehicleid, String model, double capacity, String type, String status, String fuel_type) {
		this.vehicleid = vehicleid;
		this.model = model;
		this.capacity = capacity;
		this.type = type;
		Status = status;
		this.fuel_type = fuel_type;
	}
	public vehicle() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "vehicle [vehicleid=" + vehicleid + ", model=" + model + ", capacity=" + capacity + ", type=" + type
				+ ", Status=" + Status + ", fuel_type=" + fuel_type + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(Status, capacity, fuel_type, model, type, vehicleid);
	}
	@Override
	public boolean equals(Object obj) {
		vehicle vehi = (vehicle)obj;
		if(vehi.getVehicleid() == vehicleid && vehi.getModel() == model && vehi.getCapacity() == capacity && vehi.getType() == type
				&& vehi.getStatus() == Status && vehi.getFuel_type()== fuel_type)
		{
			return true;
		}
		return false;
	}
	
	
	
	

}
