package com.java.jdbc.main;

import java.sql.SQLException;

import java.util.Scanner;

import com.java.jdbc.dao.*;
import com.java.jdbc.exceptions.BookingNotFoundException;

public class CancelBookingMain {

	public static void main(String[] args) throws BookingNotFoundException {
		
		int bookingid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Booking ID (1-40) : ");
		bookingid = sc.nextInt();
		BookingDao dao = new BookingDaoImpl();
		try {
			if(dao.CancelBooking(bookingid)) {
				System.out.println("Booking Cancelled");
			}
			else
			{
//				System.out.println("No Record Found");
				throw new BookingNotFoundException("Booking ID "+ bookingid + " Not Found");
			}
		} catch (ClassNotFoundException | SQLException |  BookingNotFoundException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}
