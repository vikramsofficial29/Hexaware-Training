package com.java.jdbc.model;

import java.util.Objects;

public class Trip {

	private int tripid;
	private int vehicleid;
	private int routeid;
	private String depaturedate;
	private String arrivaldate;
	private String tripStatus;
	private String tripType;
	private int maxPassengers;
	private int driverid;
	
	
	public int getDriverid() {
		return driverid;
	}
	public void setDriverid(int driverid) {
		this.driverid = driverid;
	}
	public int getTripid() {
		return tripid;
	}
	public void setTripid(int tripid) {
		this.tripid = tripid;
	}
	public int getVehicleid() {
		return vehicleid;
	}
	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}
	public int getRouteid() {
		return routeid;
	}
	public void setRouteid(int routeid) {
		this.routeid = routeid;
	}
	public String getDepaturedate() {
		return depaturedate;
	}
	public void setDepaturedate(String depaturedate) {
		this.depaturedate = depaturedate;
	}
	public String getArrivaldate() {
		return arrivaldate;
	}
	public void setArrivaldate(String arrivaldate) {
		this.arrivaldate = arrivaldate;
	}
	public String getTripStatus() {
		return tripStatus;
	}
	public void setTripStatus(String tripStatus) {
		this.tripStatus = tripStatus;
	}
	public String getTripType() {
		return tripType;
	}
	public void setTripType(String tripType) {
		this.tripType = tripType;
	}
	public int getMaxPassengers() {
		return maxPassengers;
	}
	public void setMaxPassengers(int maxPassengers) {
		this.maxPassengers = maxPassengers;
	}
	public Trip(int tripid, int vehicleid, int routeid, String depaturedate, String arrivaldate, String tripStatus,
			String tripType, int maxPassengers, int driverid) {
		this.tripid = tripid;
		this.vehicleid = vehicleid;
		this.routeid = routeid;
		this.depaturedate = depaturedate;
		this.arrivaldate = arrivaldate;
		this.tripStatus = tripStatus;
		this.tripType = tripType;
		this.maxPassengers = maxPassengers;
		this.driverid = driverid;
	}
	
	
	public Trip() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Trip [tripid=" + tripid + ", vehicleid=" + vehicleid + ", routeid=" + routeid + ", depaturedate="
				+ depaturedate + ", arrivaldate=" + arrivaldate + ", tripStatus=" + tripStatus + ", tripType="
				+ tripType + ", maxPassengers=" + maxPassengers + ", driverid=" + driverid + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(arrivaldate, depaturedate, driverid, maxPassengers, routeid, tripStatus, tripType, tripid,
				vehicleid);
	}
	@Override
	public boolean equals(Object obj) {
			Trip trip = (Trip)obj;
			if(trip.getTripid()== tripid
					&& trip.getVehicleid() == vehicleid
					&& trip.getRouteid() == routeid
					&& trip.getDepaturedate() == depaturedate
					&& trip.getArrivaldate() == arrivaldate
					&& trip.getTripStatus() == tripStatus
					&& trip.getTripType() == tripType
					&& trip.getMaxPassengers() == maxPassengers
					&& trip.getDriverid() == driverid)
			{
				return true;
			}
			return false;
	}
	
	
	
	
	
	
	
	
	
}
