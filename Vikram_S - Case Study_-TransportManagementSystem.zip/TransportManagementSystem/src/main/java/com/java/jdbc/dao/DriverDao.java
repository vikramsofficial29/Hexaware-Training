package com.java.jdbc.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.jdbc.model.Driver;

public interface DriverDao {
	
	boolean DeallocateDriver(int tripid) throws ClassNotFoundException, SQLException;
	List<Driver> GetAvailableDriver() throws ClassNotFoundException, SQLException;

}
