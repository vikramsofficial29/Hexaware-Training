package com.java.jdbc.main;

import java.sql.SQLException;

import java.util.Scanner;

import com.java.jdbc.model.vehicle;

import com.java.jdbc.dao.VehicleDao;
import com.java.jdbc.exceptions.VehicleNotFoundException;
import com.java.jdbc.dao.*;

public class VehicleUpdateMain {
	
	public static void main(String[] args) throws VehicleNotFoundException {
		
		vehicle vehi = new vehicle();
		Scanner sc = new Scanner(System.in);
		VehicleDao dao = new vehicleDaoImpl();
		int vehiID;
		System.out.println("Enter Vehicle ID (1-25) :");
		vehiID = sc.nextInt();
		
		vehicle vehiFound = null;
		try {
			vehiFound = dao.SearchVehicle(vehiID);
			if(vehiFound == null)
			{
				 throw new VehicleNotFoundException("Vehicle with ID " + vehiID + " not found.");
			}
		} catch (ClassNotFoundException | SQLException | VehicleNotFoundException  e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		if(vehiFound != null)
			
		{
			vehi.setVehicleid(vehiID);
			System.out.println("Enter Vehicle Model : ");
			vehi.setModel(sc.next());
			System.out.println("Enter Vehicle Capacity :");
			vehi.setCapacity(sc.nextDouble());
			System.out.println("Enter Vehicle Type(bus,van,car,truck) : ");
			vehi.setType(sc.next());
			System.out.println("Enter Vehicle Status (Available, On_Trip, Maintenance) : ");
			vehi.setStatus(sc.next());
			System.out.println("Enter Fuel Type (Petrol,Diesel) : ");
			vehi.setFuel_type(sc.next());
			
			
			try {
//				System.out.println(dao.UpdateVehicle(vehi));
				
				if(dao.UpdateVehicle(vehi))
				{
					System.out.println("Vehicle Updated");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
	}

}
