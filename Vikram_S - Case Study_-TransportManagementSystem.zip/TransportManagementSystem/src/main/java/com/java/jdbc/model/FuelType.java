//package com.java.jdbc.model;
//
//public enum FuelType {
//	
//	DIESEL,PETROL
//
//}
