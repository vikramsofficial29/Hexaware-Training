package com.java.jdbc.util;

import java.util.ResourceBundle;

public class DBPropertyUtil {
	
	public static String getConnectionString(String PropertyFile)
	{
		ResourceBundle rb = ResourceBundle.getBundle(PropertyFile);
		String connStr = rb.getString("url");
		return connStr;
	}

}
