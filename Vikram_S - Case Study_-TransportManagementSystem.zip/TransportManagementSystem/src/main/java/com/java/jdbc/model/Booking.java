package com.java.jdbc.model;

import java.util.Objects;

public class Booking {
	
	private int bookingID;
	private int tripid;
	private int passengerid;
	private String bookingDate;
	private String Status;
	public int getBookingID() {
		return bookingID;
	}
	public void setBookingID(int bookingID) {
		this.bookingID = bookingID;
	}
	public int getTripid() {
		return tripid;
	}
	public void setTripid(int tripid) {
		this.tripid = tripid;
	}
	public int getPassengerid() {
		return passengerid;
	}
	public void setPassengerid(int passengerid) {
		this.passengerid = passengerid;
	}
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Booking(int bookingID, int tripid, int passengerid, String bookingDate, String status) {
		this.bookingID = bookingID;
		this.tripid = tripid;
		this.passengerid = passengerid;
		this.bookingDate = bookingDate;
		Status = status;
	}
	public Booking() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Booking [bookingID=" + bookingID + ", tripid=" + tripid + ", passengerid=" + passengerid
				+ ", bookingDate=" + bookingDate + ", Status=" + Status + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(Status, bookingDate, bookingID, passengerid, tripid);
	}
	@Override
	public boolean equals(Object obj) {
		Booking book = (Booking)obj;
		if(book.getBookingID() == bookingID
				&& book.getTripid() == tripid
				&& book.getPassengerid() == passengerid
				&& book.getBookingDate() == bookingDate
				&& book.getStatus() == Status) {
			return true;
		}
		return false;
	}
	
	
}
