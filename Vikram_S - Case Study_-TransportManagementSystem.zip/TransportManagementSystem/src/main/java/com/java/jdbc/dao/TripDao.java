package com.java.jdbc.dao;

import java.sql.SQLException;

import com.java.jdbc.model.Trip;

public interface TripDao {
	
	boolean ScheduleTrip(Trip trip) throws ClassNotFoundException, SQLException;
	boolean CancelTrip(int tripid) throws ClassNotFoundException, SQLException;
	Trip SearchTrip(int tripid) throws ClassNotFoundException, SQLException;
	boolean AllocateDriver(int tripid, int driverid) throws ClassNotFoundException, SQLException;

}
