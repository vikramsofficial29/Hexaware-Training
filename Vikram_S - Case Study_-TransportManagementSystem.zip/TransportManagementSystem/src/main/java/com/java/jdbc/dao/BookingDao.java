package com.java.jdbc.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.jdbc.model.Booking;

public interface BookingDao {
	
	boolean AddBooking(Booking book) throws ClassNotFoundException, SQLException;
	List<Booking> getBookingByPassesnger(int passesngerid) throws ClassNotFoundException, SQLException;
	List<Booking> getBookingsByTrip(int tripid) throws ClassNotFoundException, SQLException;
	boolean CancelBooking(int bookingid) throws ClassNotFoundException, SQLException;

	
}
