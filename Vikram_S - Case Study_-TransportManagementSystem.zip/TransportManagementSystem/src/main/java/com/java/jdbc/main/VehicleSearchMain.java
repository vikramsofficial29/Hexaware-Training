package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.jdbc.dao.*;
import com.java.jdbc.exceptions.VehicleNotFoundException;
import com.java.jdbc.model.vehicle;

public class VehicleSearchMain {
	public static void main(String[] args) throws VehicleNotFoundException {
		int vehicleid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Vehicle ID (1-25) :");
		vehicleid = sc.nextInt();
		VehicleDao dao = new vehicleDaoImpl();
		try {
			vehicle vehi = dao.SearchVehicle(vehicleid);
			if(vehi != null)
			{
				System.out.println(vehi);
			}
			else
			{
				throw new VehicleNotFoundException("Vehicle ID " + vehicleid + " not found.");
			}
		} catch (ClassNotFoundException | SQLException | VehicleNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}
