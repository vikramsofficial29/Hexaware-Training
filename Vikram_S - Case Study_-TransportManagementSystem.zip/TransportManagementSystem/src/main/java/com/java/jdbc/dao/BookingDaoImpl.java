package com.java.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.jdbc.model.Booking;
import com.java.jdbc.util.DBConnUtil;
import com.java.jdbc.util.DBPropertyUtil;

public class BookingDaoImpl implements BookingDao {

	Connection connection;
	PreparedStatement pst;
	@Override
	public boolean AddBooking(Booking book) throws ClassNotFoundException, SQLException {
		
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Insert into booking(trip_id,passengerid,bookingdate,status)"
		+ "values(?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, book.getTripid());
		pst.setInt(2, book.getPassengerid());
		pst.setString(3, book.getBookingDate());
		pst.setString(4, book.getStatus());
		int AffectedRows = pst.executeUpdate();
		return AffectedRows > 0;
		
	}
	@Override
	public List<Booking> getBookingByPassesnger(int passesngerid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from booking where passengerid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, passesngerid);
		ResultSet rs = pst.executeQuery();
		List<Booking> BookingListByPid = new ArrayList<Booking>();
		Booking book = null;
		while(rs.next())
		{
			book = new Booking();
			book.setBookingID(rs.getInt("bookingid"));
			book.setTripid(rs.getInt("trip_id"));
			book.setPassengerid(rs.getInt("passengerid"));
			book.setBookingDate(rs.getString("bookingDate"));
			book.setStatus(rs.getString("status"));
			BookingListByPid.add(book);
		}
		
		return BookingListByPid;
	}
	@Override
	public List<Booking> getBookingsByTrip(int tripid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from booking where trip_id = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, tripid);
		ResultSet rs = pst.executeQuery();
		List<Booking> BookingListByTripid = new ArrayList<Booking>();
		Booking book = null;
		while(rs.next())
		{
			book = new Booking();
			book.setBookingID(rs.getInt("bookingid"));
			book.setTripid(rs.getInt("trip_id"));
			book.setPassengerid(rs.getInt("passengerid"));
			book.setBookingDate(rs.getString("bookingDate"));
			book.setStatus(rs.getString("status"));
			BookingListByTripid.add(book);
		}
		
		return BookingListByTripid;
		
	}
	@Override
	public boolean CancelBooking(int bookingid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "delete from booking where bookingid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, bookingid);
		int AffectedRows = pst.executeUpdate();
		return AffectedRows > 0;
		
	}

}
