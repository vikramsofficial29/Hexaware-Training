package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.jdbc.dao.*;
import com.java.jdbc.model.Trip;

public class ScheduleTripMain {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TripDao dao = new TripDaoImpl();
		
		Trip trip = new Trip();
		System.out.println("Enter The Vehicle ID (1-25) :");
		trip.setVehicleid(sc.nextInt());
		System.out.println("Enter The Route ID (1-30) :");
		trip.setRouteid(sc.nextInt());
		System.out.println("Enter The Arrival Date (yyyy-mm-dd) : ");
		trip.setArrivaldate(sc.next());
		System.out.println("Enter The Departure Date (yyyy-mm-dd) : ");
		trip.setDepaturedate(sc.next());
		trip.setTripStatus("Scheduled");
		trip.setTripType("Passenger");
		trip.setMaxPassengers(100);
		
		
		try {
			if(dao.ScheduleTrip(trip))
			{
				System.out.println("Trip Scheduled Successfully");
			}
			else
			{
				System.out.println("Not Scheduled");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
