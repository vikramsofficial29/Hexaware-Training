package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.jdbc.dao.*;
import com.java.jdbc.model.vehicle;

public class VehicleInsertMain {
	
	public static void main(String[] args) {
		
		vehicle vehi = new vehicle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Vehicle Model : ");
		vehi.setModel(sc.next());
		System.out.println("Enter Vehicle Capacity :");
		vehi.setCapacity(sc.nextDouble());
		System.out.println("Enter Vehicle Type(bus,van,car,truck) : ");
		vehi.setType(sc.next());
		System.out.println("Enter Vehicle Status (Available, On_Trip, Maintenance) : ");
		vehi.setStatus(sc.next());
		System.out.println("Enter Fuel Type (Petrol,Diesel) : ");
		vehi.setFuel_type(sc.next());
		
		
		VehicleDao dao = new vehicleDaoImpl();
		try {
			
			if(dao.AddVehicle(vehi))
			{
				System.out.println("Vehicle Inserted Successfully");
			}
			else
			{
				System.out.println("Vehicle not Inserted");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
