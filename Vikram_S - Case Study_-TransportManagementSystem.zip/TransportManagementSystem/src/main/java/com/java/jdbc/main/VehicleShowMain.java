package com.java.jdbc.main;

import com.java.jdbc.dao.VehicleDao;
import com.java.jdbc.model.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.jdbc.dao.*;

public class VehicleShowMain {


public static void main(String[] args) {	
	
	VehicleDao dao = new vehicleDaoImpl();
	try {
		List<vehicle> vehiclelist = dao.ShowVehicleDao();
		for ( vehicle vehicle : vehiclelist) {
			System.out.println(vehicle);
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	


}
}