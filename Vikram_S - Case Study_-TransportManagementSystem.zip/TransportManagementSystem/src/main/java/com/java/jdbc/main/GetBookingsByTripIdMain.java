package com.java.jdbc.main;

import java.sql.SQLException;

import java.util.List;
import java.util.Scanner;

import com.java.jdbc.dao.*;
import com.java.jdbc.dao.BookingDao;
import com.java.jdbc.dao.BookingDaoImpl;
import com.java.jdbc.exceptions.BookingNotFoundException;
import com.java.jdbc.exceptions.VehicleNotFoundException;
import com.java.jdbc.model.Booking;
import com.java.jdbc.model.Trip;
import com.java.jdbc.model.vehicle;

public class GetBookingsByTripIdMain {

	public static void main(String[] args) throws BookingNotFoundException {
		int tripid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Trip ID (1-60) :");
		tripid = sc.nextInt();
		
		
		
		TripDao Tdao = new TripDaoImpl();
		Trip tripFound = null;
		try {
			tripFound = Tdao.SearchTrip(tripid);
			if(tripFound == null)
			{
				throw new BookingNotFoundException("Bookings Not Found For the Given Trip ID : "+ tripid);
			}
		} catch (ClassNotFoundException | SQLException | BookingNotFoundException  e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		
		
		
		BookingDao dao = new BookingDaoImpl();
		try {
			List<Booking> BookListbyTid = dao.getBookingsByTrip(tripid);
			for (Booking booking : BookListbyTid) {
				System.out.println(booking);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
