package com.java.jdbc.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.jdbc.dao.*;

import com.java.jdbc.model.Booking;

public class AddBookingMain {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Booking book = new Booking();
		BookingDao dao = new BookingDaoImpl();
		
		System.out.println("Enter The Trip ID (1-60) :");
		book.setTripid(sc.nextInt());
		System.out.println("Enter The Passesnger ID (1-15) : ");
		book.setPassengerid(sc.nextInt());
		System.out.println("Enter The Booking Date (yyyy-mm-dd) : ");
		book.setBookingDate(sc.next());
		System.out.println("Enter The Status (Confirmed / Cancelled) : ");
		book.setStatus(sc.next());
		
		try {
			if(dao.AddBooking(book))
			{
				System.out.println("Booking Added");
			}
			else
			{
				System.out.println("Not Added");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	
	
	}

}
