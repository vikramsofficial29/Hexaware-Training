package com.java.jdbc.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.jdbc.model.vehicle;

public interface VehicleDao {
	
	List<vehicle> ShowVehicleDao() throws ClassNotFoundException, SQLException;
		vehicle	SearchVehicle(int vehicleid) throws ClassNotFoundException, SQLException;
		boolean	AddVehicle(vehicle vehi) throws ClassNotFoundException, SQLException;
		boolean UpdateVehicle(vehicle vehi) throws ClassNotFoundException, SQLException;
		boolean DeleteVehicle(int vehicleid) throws ClassNotFoundException, SQLException;
}
