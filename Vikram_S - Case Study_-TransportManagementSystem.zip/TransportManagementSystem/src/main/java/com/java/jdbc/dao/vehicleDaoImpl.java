package com.java.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.jdbc.model.vehicle;
import com.java.jdbc.util.DBConnUtil;
import com.java.jdbc.util.DBPropertyUtil;

public class vehicleDaoImpl  implements VehicleDao {

	Connection connection;
	PreparedStatement pst;
	@Override
	public List<vehicle> ShowVehicleDao() throws ClassNotFoundException, SQLException {
		
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from Vehicle";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		
		List<vehicle> vehiList = new ArrayList<vehicle>();
		vehicle veh = null;
		while(rs.next())
		{
			veh = new vehicle();
			veh.setVehicleid(rs.getInt("vehicleid"));
			veh.setModel(rs.getString("model"));
			veh.setCapacity(rs.getDouble("capacity"));
			veh.setType(rs.getString("type"));
			veh.setStatus(rs.getString("status"));
			veh.setFuel_type(rs.getString("fuel_type"));
			vehiList.add(veh);
			
		}
		
		return vehiList;
	}
	@Override
	public boolean AddVehicle(vehicle vehi) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Insert Into Vehicle(model,capacity,type,status,fuel_type)"+ "values(?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, vehi.getModel());
		pst.setDouble(2, vehi.getCapacity());
		pst.setString(3, vehi.getType());
		pst.setString(4, vehi.getStatus());
		pst.setString(5, vehi.getFuel_type());
		int AffectedRows = pst.executeUpdate();
		return AffectedRows > 0;
	}
	@Override
	public vehicle SearchVehicle(int vehicleid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.getConnectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Select * from vehicle where vehicleid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, vehicleid);
		ResultSet rs = pst.executeQuery();
		vehicle veh = null;
		if(rs.next())
		{
			veh = new vehicle();
			veh.setVehicleid(rs.getInt("vehicleid"));
			veh.setModel(rs.getString("model"));
			veh.setCapacity(rs.getDouble("capacity"));
			veh.setType(rs.getString("type"));
			veh.setStatus(rs.getString("status"));
			veh.setFuel_type(rs.getString("fuel_type"));
			
		}
		return veh;
		
	}
	@Override
	public boolean UpdateVehicle(vehicle vehi) throws ClassNotFoundException, SQLException {
			String ConnStr = DBPropertyUtil.getConnectionString("db");
			connection = DBConnUtil.getConnection(ConnStr);
			String cmd = "Update Vehicle set model = ? , capacity = ? , type = ? , status = ?, fuel_type = ? where vehicleid = ?";
			pst = connection.prepareStatement(cmd);
			pst.setString(1, vehi.getModel());
			pst.setDouble(2, vehi.getCapacity());
			pst.setString(3, vehi.getType());
			pst.setString(4, vehi.getStatus());
			pst.setString(5, vehi.getFuel_type());
			pst.setInt(6, vehi.getVehicleid());
			int AffectedRows = pst.executeUpdate();
			return AffectedRows > 0;
		
		
		
		
	}
	@Override
	public boolean DeleteVehicle(int vehicleid) throws ClassNotFoundException, SQLException {
		
		vehicle vehiFound = SearchVehicle(vehicleid);
		if(vehiFound != null)
		{
			String ConnStr = DBPropertyUtil.getConnectionString("db");
			connection = DBConnUtil.getConnection(ConnStr);
			String cmd = "Delete from vehicle where vehicleid = ?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, vehicleid);
			int AffectedRows = pst.executeUpdate();
			return AffectedRows > 0;
		}
		return false;
	}
	
	
	

}
